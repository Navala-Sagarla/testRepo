package com.practise.exceptionhandling;
import java.io.*; 
import java.util.*; 
class Sender1 
{ 
    public void send(String msg) 
    { 
        System.out.println("Sending\t"  + msg ); 
        try
        { 
            Thread.sleep(1000); 
        } 
        catch (Exception e) 
        { 
            System.out.println("Thread  interrupted."); 
        } 
        System.out.println("\n" + msg + "Sent"); 
    } 
} 
class ThreadedSend1 extends Thread 
{ 
    private String msg; 
    private Thread t; 
    Sender  sender; 
    ThreadedSend1(String m,  Sender obj) 
    { 
        msg = m; 
        sender = obj; 
    } 
  
    public void run() 
    {  
        synchronized(sender) 
        { 
            sender.send(msg); 
        } 
    } 
} 
public class SyncDemo3 {
	
	
	public static void main(String args[]) 
	    { 
	        Sender snd = new Sender(); 
	        ThreadedSend1 S1 = 
	            new ThreadedSend1( " Hi " , snd ); 
	        ThreadedSend1 S2 = 
	            new ThreadedSend1( " Bye " , snd ); 
	        S1.start(); 
	        S2.start(); 
	        try
	        { 
	            S1.join(); 
	            S2.join(); 
	        } 
	        catch(Exception e) 
	        { 
	            System.out.println("Interrupted"); 
	        } 
	    } 
	} 


