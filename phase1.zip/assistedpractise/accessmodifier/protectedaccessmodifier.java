package com.mphasis.accessmodifier;
class promodifier{
protected 	void disp() {
	System.out.println("protected modifier");
	
}
	
}
public class protectedaccessmodifier {
	public static void main(String[] args) {
		
		promodifier name=new promodifier();
		name.disp();
	}

}

