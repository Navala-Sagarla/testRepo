package com.mphasis.accessmodifier;

class dmodifier{
	
	void display()
	{
		System.out.println("Default access modifier");
	}
	
}

public class defaultaccessmodifier {
	
	public static void main(String[] args) {
		
    dmodifier defa=new dmodifier();
		defa.display();
		
		
	}

}
