package com.mphasis.accessmodifier;

class publicmodifier{
public void disp() {
	System.out.println("public modifier");
	
}
	
}
public class publicaccessmodifier {
	public static void main(String[] args) {
		
		publicmodifier name=new publicmodifier();
		name.disp();
	}

}