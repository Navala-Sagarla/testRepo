package com.mphasis.accessmodifier;

class pmodifier{
	
	private  void display()
	{
		System.out.println("Private access modifier");
	}
}

public class privateaccessmodifier {
public static void main(String[] args) {
	
	pmodifier ab=new pmodifier();
	ab.display();
}
}
