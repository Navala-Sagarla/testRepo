package com.mphasis.constructors;

class Std{
	int id;
	String name;

	Std(int i,String n)
	{
	this.id=i;
	this.name=n;
	}

	public void display() {
	System.out.println(this.id+" "+this.name);
	}
}

public class pm {
public static void main(String[] args) {

	Std std1=new Std(2,"Mango");
	Std std2=new Std(3,"apple");
	
	std1.display();
	std2.display();

		}
}